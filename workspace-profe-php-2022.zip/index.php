<?php
include_once($_SERVER["DOCUMENT_ROOT"] . "/cabecera.php");
?>

      <div class="col-md-10 themed-grid-col">
		<div class="p-3 bg-white">
			
			<h2>BIENVENIDO A LA WEB DE LOS EJERCICIOS PHP DEL PROFESOR</h2>

		</div>
	  </div>
    </div>

<?php
    include_once($_SERVER["DOCUMENT_ROOT"] . "/pie.php");
?>